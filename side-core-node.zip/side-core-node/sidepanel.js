
(function () {
  const KEYS = {
    chats: 'side_core_chats_v1',
    current: 'side_core_current',
    theme: 'side_theme'
  };

  const $ = (id) => document.getElementById(id);
  const chatEl = $('chat');
  const input = $('input');
  const welcome = $('welcome');
  const sendBtn = $('btn-send');
  const listEl = $('chat-list');
  const ctx = $('ctx-menu');
  const composer = $('composer');
  const attachRow = $('attach-row');
  const fileInput = $('file-input');
  const plusMenu = $('plus-menu');

  let state = {
    chats: {},
    currentId: null,
    ctxId: null,
    pending: [], // {id,name,size,type,dataUrl,isImage}
    tabInfo: { title: '', url: '' }
  };

  /* ===== Bridge + External API ===== */
  let bridgeApi = null; // { enabled, provider, key, importedContext }
  let bridgeTs = 0;

  function parseBridgePayload(payload) {
    if (!payload) return;
    try {
      if (payload.oracle_custom_api) {
        const api = typeof payload.oracle_custom_api === 'string'
          ? JSON.parse(payload.oracle_custom_api)
          : payload.oracle_custom_api;
        // SIDE prefer: if local side API enabled, keep it
        if (bridgeApi && bridgeApi._fromSide && bridgeApi.enabled && bridgeApi.key) return;
        if (payload._from === 'side') api._fromSide = true;
        bridgeApi = api;
      }
    } catch (e) { /* keep existing bridgeApi */ }
  }

  function refreshBridge() {
    try {
      chrome.runtime.sendMessage({ type: 'cn-bridge-get' }, (res) => {
        if (chrome.runtime.lastError) return;
        if (res && res.payload) {
          parseBridgePayload(res.payload);
          bridgeTs = res.ts || 0;
          updateBridgeBadge();
        }
      });
    } catch (e) {}
  }

  function updateBridgeBadge() {
    const meta = document.querySelector('.composer-meta');
    if (!meta) return;
    const on = bridgeApi && bridgeApi.enabled && bridgeApi.key && bridgeApi.provider;
    meta.textContent = on
      ? ('API: ' + bridgeApi.provider + ' · из Core Node')
      : 'Alt+Shift+C · локально · API → Core Node';
  }

  
  /* ===== Settings panel ===== */
  const SIDE_API_KEY = 'side_core_api_v1';
  const SIDE_ACCENT_KEY = 'side_accent';

  let _settingsOpenedAt = 0;
  function openSettings(e) {
    try {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
      }
    } catch (err) {}
    const d = document.getElementById('settings-drawer');
    const o = document.getElementById('settings-overlay');
    if (!d) { console.warn('settings-drawer missing'); return; }
    _settingsOpenedAt = Date.now();
    d.classList.add('open');
    if (o) o.classList.add('open');
    try { syncSettingsUI(); } catch (err) { console.warn(err); }
  }
  function closeSettings(e) {
    // same-click fallthrough: ignore close right after open
    if (Date.now() - _settingsOpenedAt < 400) return;
    try {
      if (e) { e.preventDefault(); e.stopPropagation(); }
    } catch (err) {}
    document.getElementById('settings-drawer')?.classList.remove('open');
    document.getElementById('settings-overlay')?.classList.remove('open');
  }
  window.__openSideSettings = openSettings;
  window.__closeSideSettings = closeSettings;

  async function loadSideApiLocal() {
    const r = await storageGet([SIDE_API_KEY, SIDE_ACCENT_KEY]);
    if (r[SIDE_API_KEY]) {
      try {
        const a = typeof r[SIDE_API_KEY] === 'string' ? JSON.parse(r[SIDE_API_KEY]) : r[SIDE_API_KEY];
        if (a && a.key) {
          // local overrides bridge if enabled
          if (a.enabled) bridgeApi = a;
          else if (!bridgeApi) bridgeApi = a;
        }
      } catch (e) {}
    }
    if (r[SIDE_ACCENT_KEY]) applyAccent(r[SIDE_ACCENT_KEY], false);
    updateBridgeBadge();
  }

  function applyAccent(color, save) {
    if (!color) return;
    document.documentElement.style.setProperty('--accent', color);
    // light theme may need darker accent - keep same
    document.querySelectorAll('.accent-dot').forEach(d => {
      d.classList.toggle('active', d.dataset.accent === color);
    });
    if (save !== false) storageSet({ [SIDE_ACCENT_KEY]: color });
  }

  function syncSettingsUI() {
    const theme = document.body.dataset.theme || 'dark';
    document.querySelectorAll('[data-theme-set]').forEach(b => {
      b.classList.toggle('active', b.dataset.themeSet === theme);
    });
    const api = bridgeApi || {};
    const en = $('set-api-enabled');
    if (en) en.checked = !!api.enabled;
    document.querySelectorAll('[data-provider]').forEach(b => {
      b.classList.toggle('active', b.dataset.provider === (api.provider || ''));
    });
    const keyInp = $('set-api-key');
    if (keyInp && api.key && keyInp.value !== api.key) {
      keyInp.value = api.key;
    }
    const st = $('set-api-status');
    if (st) {
      if (api.enabled && api.key && api.provider) {
        st.textContent = 'Статус: ' + api.provider + ' · ключ задан';
      } else {
        st.textContent = 'Статус: локально / без ключа (или мост CN)';
      }
    }
  }

  async function saveSideApiFromForm() {
    const enabled = !!$('set-api-enabled')?.checked;
    const provider = document.querySelector('#set-providers .set-chip.active')?.dataset?.provider || 'gemini';
    const key = ($('set-api-key')?.value || '').trim();
    if (enabled && key.length < 10) {
      showToast('Вставьте ключ API', 'error');
      return;
    }
    const api = { enabled, provider, key, _fromSide: true };
    bridgeApi = api;
    await storageSet({ [SIDE_API_KEY]: api });
    // also push into bridge storage so consistent
    try {
      chrome.runtime.sendMessage({
        type: 'cn-bridge-sync',
        reason: 'side-settings',
        payload: { oracle_custom_api: JSON.stringify(api), _ts: Date.now(), _from: 'side' }
      });
    } catch (e) {}
    updateBridgeBadge();
    syncSettingsUI();
    showToast(enabled ? ('API ' + provider + ' сохранён') : 'API выключен', 'success');
    closeSettings();
  }

  // wire settings once DOM ready - append to end before loadAll

async function callExternalFromSide(userMsg) {
    const s = bridgeApi;
    if (!s || !s.enabled || !s.key || !s.provider) {
      return { ok: false, error: 'not_configured' };
    }
    const provider = String(s.provider).toLowerCase();
    const key = String(s.key).trim();
    const context = s.importedContext ? ('\n\n[Контекст]\n' + String(s.importedContext).slice(0, 3000)) : '';
    const prompt = userMsg + context;
    try {
      if (provider === 'gemini') {
        const model = 'gemini-2.0-flash';
        const url = 'https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent?key=' + encodeURIComponent(key);
        const res = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
          body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }] })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          const errMsg = data?.error?.message || ('HTTP ' + res.status);
          return { ok: false, error: String(errMsg), code: 'api_error' };
        }
        const text = (data?.candidates?.[0]?.content?.parts || []).map(p => p.text).filter(Boolean).join('\n');
        if (!text) return { ok: false, error: 'Пустой ответ Gemini', code: 'empty' };
        return { ok: true, text };
      }
      if (provider === 'openai') {
        const res = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
          body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: prompt }] })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) return { ok: false, error: data?.error?.message || ('HTTP ' + res.status), code: 'api_error' };
        const text = data?.choices?.[0]?.message?.content || '';
        if (!text) return { ok: false, error: 'Пустой ответ', code: 'empty' };
        return { ok: true, text };
      }
      if (provider === 'claude') {
        const res = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': key,
            'anthropic-version': '2023-06-01'
          },
          body: JSON.stringify({
            model: 'claude-3-5-haiku-20241022',
            max_tokens: 1024,
            messages: [{ role: 'user', content: prompt }]
          })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) return { ok: false, error: data?.error?.message || ('HTTP ' + res.status), code: 'api_error' };
        const text = (data?.content || []).map(c => c.text).filter(Boolean).join('\n');
        if (!text) return { ok: false, error: 'Пустой ответ', code: 'empty' };
        return { ok: true, text };
      }
      if (provider === 'grok') {
        const res = await fetch('https://api.x.ai/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
          body: JSON.stringify({ model: 'grok-2-latest', messages: [{ role: 'user', content: prompt }] })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) return { ok: false, error: data?.error?.message || ('HTTP ' + res.status), code: 'api_error' };
        const text = data?.choices?.[0]?.message?.content || '';
        if (!text) return { ok: false, error: 'Пустой ответ', code: 'empty' };
        return { ok: true, text };
      }
      return { ok: false, error: 'unsupported' };
    } catch (e) {
      return { ok: false, error: 'Сеть: ' + (e.message || e), code: 'network' };
    }
  }

  function mdLite(text) {
    return escapeHtml(text)
      .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
      .replace(/\n/g, '<br>');
  }



  let _modalResolve = null;

  function uid() {
    return 'sc_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  function storageGet(keys) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(keys, (r) => resolve(r || {}));
      } catch (e) {
        const out = {};
        keys.forEach((k) => {
          try { out[k] = JSON.parse(localStorage.getItem(k)); } catch (_) {
            out[k] = localStorage.getItem(k);
          }
        });
        resolve(out);
      }
    });
  }

  function storageSet(obj) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set(obj, () => resolve());
      } catch (e) {
        Object.keys(obj).forEach((k) => {
          const v = obj[k];
          localStorage.setItem(k, typeof v === 'string' ? v : JSON.stringify(v));
        });
        resolve();
      }
    });
  }

  function showToast(msg, type) {
    const host = $('toast-host');
    if (!host) return;
    const t = document.createElement('div');
    t.className = 'toast' + (type ? ' ' + type : '');
    t.textContent = msg;
    host.appendChild(t);
    setTimeout(() => {
      t.style.opacity = '0';
      t.style.transition = 'opacity .25s';
      setTimeout(() => t.remove(), 280);
    }, 2800);
  }

  function openModal({ title, body, input, okText, danger, placeholder }) {
    return new Promise((resolve) => {
      _modalResolve = resolve;
      $('modal-title').textContent = title || 'Подтверждение';
      $('modal-body').textContent = body || '';
      const inp = $('modal-input');
      if (input) {
        inp.hidden = false;
        inp.value = input.value || '';
        inp.placeholder = placeholder || '';
        setTimeout(() => inp.focus(), 50);
      } else {
        inp.hidden = true;
        inp.value = '';
      }
      const ok = $('modal-ok');
      ok.textContent = okText || 'OK';
      ok.classList.toggle('danger', !!danger);
      $('modal-ov').classList.add('open');
    });
  }
  function closeModal(result) {
    $('modal-ov').classList.remove('open');
    const r = _modalResolve;
    _modalResolve = null;
    if (r) r(result);
  }
  {
    const __c = $('modal-cancel');
    if (__c) __c.onclick = () => closeModal(null);
  }
  {
    const __ok = $('modal-ok');
    if (__ok) __ok.onclick = () => {
      const inp = $('modal-input');
      if (inp && !inp.hidden) closeModal({ value: inp.value });
      else closeModal(true);
    };
  }
  {
    const __ov = $('modal-ov');
    if (__ov) __ov.onclick = (e) => { if (e.target === __ov) closeModal(null); };
  }

  function pulseComposer() {
    composer.classList.remove('pulse-ring');
    void composer.offsetWidth;
    composer.classList.add('pulse-ring');
    setTimeout(() => composer.classList.remove('pulse-ring'), 1000);
  }

  async function loadAll() {
    const r = await storageGet([KEYS.chats, KEYS.current, KEYS.theme]);
    state.chats = r[KEYS.chats] && typeof r[KEYS.chats] === 'object' ? r[KEYS.chats] : {};
    if (typeof state.chats === 'string') {
      try { state.chats = JSON.parse(state.chats); } catch (_) { state.chats = {}; }
    }
    state.currentId = r[KEYS.current] || null;
    const theme = r[KEYS.theme] || 'dark';
    document.body.dataset.theme = theme;
    const __thi = $('theme-icon'); if (__thi) __thi.textContent = theme === 'dark' ? 'light_mode' : 'dark_mode';
    if (!state.currentId || !state.chats[state.currentId]) await newChat(false);
    else renderChat();
    renderList();
    refreshTabChip();
    setTimeout(pulseComposer, 400);
  }

  async function saveChats() {
    await storageSet({ [KEYS.chats]: state.chats, [KEYS.current]: state.currentId });
  }

  async function newChat(focusInput) {
    const id = uid();
    state.chats[id] = { title: 'Новый чат', messages: [], updated: Date.now() };
    state.currentId = id;
    state.pending = [];
    renderAttach();
    await saveChats();
    renderChat();
    renderList();
    closeDrawer();
    if (focusInput !== false) {
      input.focus();
      pulseComposer();
    }
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function renderChat() {
    const c = state.chats[state.currentId];
    chatEl.innerHTML = '';
    if (!c || !c.messages || !c.messages.length) {
      welcome.classList.remove('hidden');
      return;
    }
    welcome.classList.add('hidden');
    c.messages.forEach((m) => {
      const b = document.createElement('div');
      b.className = 'bubble ' + (m.role === 'user' ? 'user' : m.role === 'system' ? 'system' : 'ai');
      b.innerHTML = m.html || escapeHtml(m.text || '');
      chatEl.appendChild(b);
    });
    $('main').scrollTop = $('main').scrollHeight;
  }

  function renderList() {
    listEl.innerHTML = '';
    const ids = Object.keys(state.chats).sort(
      (a, b) => (state.chats[b].updated || 0) - (state.chats[a].updated || 0)
    );
    if (!ids.length) {
      listEl.innerHTML = '<div style="padding:12px;color:var(--sub);font-size:12px">Пусто</div>';
      return;
    }
    ids.forEach((id) => {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'chat-item' + (id === state.currentId ? ' active' : '');
      item.innerHTML =
        '<span class="material-symbols-rounded" style="font-size:18px;color:var(--sub)">chat</span>' +
        '<span class="title"></span>';
      item.querySelector('.title').textContent = state.chats[id].title || 'Чат';
      item.onclick = () => openChat(id);
      item.oncontextmenu = (e) => {
        e.preventDefault();
        openCtx(e.clientX, e.clientY, id);
      };
      listEl.appendChild(item);
    });
  }

  async function openChat(id) {
    if (!state.chats[id]) return;
    state.currentId = id;
    state.pending = [];
    renderAttach();
    await saveChats();
    renderChat();
    renderList();
    closeDrawer();
  }

  function openDrawer() {
    $('history-drawer').classList.add('open');
    $('drawer-overlay').classList.add('open');
    renderList();
  }
  function closeDrawer() {
    $('history-drawer').classList.remove('open');
    $('drawer-overlay').classList.remove('open');
    closeCtx();
  }

  function openCtx(x, y, id) {
    state.ctxId = id;
    ctx.classList.add('open');
    const pad = 8, w = 160, h = 90;
    ctx.style.left = Math.min(x, window.innerWidth - w - pad) + 'px';
    ctx.style.top = Math.min(y, window.innerHeight - h - pad) + 'px';
  }
  function closeCtx() {
    ctx.classList.remove('open');
    state.ctxId = null;
  }

  async function renameChat(id) {
    const c = state.chats[id];
    if (!c) return;
    const res = await openModal({
      title: 'Переименовать',
      body: 'Новое название чата',
      input: { value: c.title || '' },
      okText: 'Сохранить'
    });
    if (!res) return;
    c.title = (res.value || '').trim() || 'Без названия';
    c.updated = Date.now();
    await saveChats();
    renderList();
    showToast('Название сохранено', 'success');
  }

  async function deleteChat(id) {
    if (!state.chats[id]) return;
    const ok = await openModal({
      title: 'Удалить чат?',
      body: '«' + (state.chats[id].title || 'чат') + '» будет удалён без восстановления.',
      okText: 'Удалить',
      danger: true
    });
    if (!ok) return;
    delete state.chats[id];
    if (state.currentId === id) {
      const rest = Object.keys(state.chats);
      if (rest.length) {
        state.currentId = rest.sort((a, b) => (state.chats[b].updated || 0) - (state.chats[a].updated || 0))[0];
      } else {
        await newChat(false);
        showToast('Чат удалён', 'success');
        return;
      }
    }
    await saveChats();
    renderChat();
    renderList();
    showToast('Чат удалён', 'success');
  }

  function updateSend() {
    const on = input.value.trim().length > 0 || state.pending.length > 0;
    sendBtn.classList.toggle('active', on);
    sendBtn.disabled = !on;
  }

  function autoResize() {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 120) + 'px';
  }

  function formatBytes(n) {
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(1) + ' MB';
  }

  function renderAttach() {
    if (!state.pending.length) {
      attachRow.hidden = true;
      attachRow.innerHTML = '';
      updateSend();
      return;
    }
    attachRow.hidden = false;
    attachRow.innerHTML = '';
    state.pending.forEach((f) => {
      const chip = document.createElement('div');
      chip.className = 'attach-chip';
      if (f.isImage && f.dataUrl) {
        chip.innerHTML =
          '<img alt=""/><div class="meta"><div class="name"></div><div class="size"></div></div>' +
          '<button type="button" class="rm" title="Убрать"><span class="material-symbols-rounded">close</span></button>';
        chip.querySelector('img').src = f.dataUrl;
      } else {
        chip.innerHTML =
          '<span class="material-symbols-rounded" style="color:var(--sub)">draft</span>' +
          '<div class="meta"><div class="name"></div><div class="size"></div></div>' +
          '<button type="button" class="rm" title="Убрать"><span class="material-symbols-rounded">close</span></button>';
      }
      chip.querySelector('.name').textContent = f.name;
      chip.querySelector('.size').textContent = formatBytes(f.size);
      chip.querySelector('.rm').onclick = () => {
        state.pending = state.pending.filter((x) => x.id !== f.id);
        renderAttach();
      };
      attachRow.appendChild(chip);
    });
    updateSend();
  }

  function addFiles(fileList) {
    const files = Array.from(fileList || []);
    files.forEach((file) => {
      if (file.size > 12 * 1024 * 1024) {
        showToast('Файл больше 12 МБ: ' + file.name, 'error');
        return;
      }
      const item = {
        id: uid(),
        name: file.name,
        size: file.size,
        type: file.type || 'application/octet-stream',
        dataUrl: null,
        isImage: !!(file.type && file.type.startsWith('image/'))
      };
      if (item.isImage) {
        const reader = new FileReader();
        reader.onload = () => {
          item.dataUrl = reader.result;
          state.pending.push(item);
          renderAttach();
        };
        reader.readAsDataURL(file);
      } else {
        state.pending.push(item);
        renderAttach();
      }
    });
  }

  function refreshTabChip() {
    const text = $('tab-chip-text');
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs && tabs[0];
        if (tab) {
          state.tabInfo = { title: tab.title || '', url: tab.url || '' };
          text.textContent = tab.title || tab.url || 'Текущая вкладка';
        } else {
          text.textContent = 'Анализ вкладки';
        }
      });
    } catch (e) {
      text.textContent = 'Анализ вкладки (нужны разрешения)';
    }
  }

  function analyzeTab() {
    refreshTabChip();
    const { title, url } = state.tabInfo;
    if (!url && !title) {
      showToast('Не удалось получить вкладку', 'error');
      return;
    }
    const q = 'Проанализируй вкладку: ' + (title || '') + (url ? ' — ' + url : '');
    input.value = q;
    autoResize();
    updateSend();
    pulseComposer();
    showToast('Вкладка подставлена в запрос', 'success');
  }

  function localReply(q, attaches, tab) {
    const x = q.toLowerCase();
    let extra = '';
    if (attaches && attaches.length) {
      extra += '<br><br>📎 Вложения: ' + attaches.map((a) => escapeHtml(a.name)).join(', ');
    }
    if (tab && (tab.title || tab.url)) {
      extra += '<br><br>🗂 Контекст вкладки: <b>' + escapeHtml(tab.title || '') + '</b><br><span style="font-size:11px;color:var(--sub)">' + escapeHtml(tab.url || '') + '</span>';
    }
    if (x.includes('вкладк') || x.includes('tab') || x.includes('сайт') || x.includes('http')) {
      return 'Анализ вкладки (локально, без API):<br><b>' + escapeHtml(tab?.title || '—') + '</b><br><span style="font-size:12px;color:var(--sub)">' + escapeHtml(tab?.url || 'URL недоступен') + '</span><br><br>Для глубокого разбора страницы откройте полный <b>Core Node</b> и подключите API.' + extra;
    }
    if (x.includes('core node') || x.includes('side')) {
      return 'Я <b>Side Core Node</b> — урезанный спутник Core Node PRO. API только в полном приложении.' + extra;
    }
    if (x.includes('привет') || x.includes('hello')) {
      return 'Привет. Задавайте вопросы — ответы на основе источников и контекста вкладки (локальный режим).' + extra;
    }
    return 'Принято: «' + escapeHtml(q || 'вложение') + '».<br><br><span style="color:var(--sub);font-size:12px">Локальный ответ Side Core Node. Внешние модели — через Core Node.</span>' + extra;
  }

  async function send() {
    const text = input.value.trim();
    if (!text && !state.pending.length) return;
    const c = state.chats[state.currentId];
    if (!c) return;

    const attaches = state.pending.slice();
    let userHtml = escapeHtml(text || '');
    if (attaches.length) {
      const parts = attaches.map((a) => {
        if (a.isImage && a.dataUrl) {
          return '<div class="bubble-attach"><img src="' + a.dataUrl + '" alt=""/></div>';
        }
        return '<div class="bubble-attach"><div class="file-pill"><span class="material-symbols-rounded" style="font-size:16px">draft</span> ' + escapeHtml(a.name) + '</div></div>';
      });
      userHtml = parts.join('') + (text ? '<div>' + escapeHtml(text) + '</div>' : '');
    }

    c.messages.push({ role: 'user', text: text || attaches.map((a) => a.name).join(', '), html: userHtml });
    if (c.title === 'Новый чат') {
      c.title = (text || attaches[0]?.name || 'Чат').slice(0, 40) + ((text || '').length > 40 ? '…' : '');
    }
    c.updated = Date.now();
    state.pending = [];
    renderAttach();
    input.value = '';
    autoResize();
    updateSend();
    renderChat();
    await saveChats();
    renderList();

    const typing = document.createElement('div');
    typing.className = 'bubble ai thinking-bubble';
    typing.id = 'typing';
    typing.innerHTML =
      '<div class="think-row">' +
        '<span class="think-orbit" aria-hidden="true">' +
          '<span class="think-dot d1"></span>' +
          '<span class="think-dot d2"></span>' +
          '<span class="think-dot d3"></span>' +
        '</span>' +
        '<span class="think-label">Думаю<span class="think-dots"></span></span>' +
      '</div>';
    chatEl.appendChild(typing);
    welcome.classList.add('hidden');
    $('main').scrollTop = $('main').scrollHeight;

    const tabSnap = { ...state.tabInfo };
    refreshBridge();
    setTimeout(async () => {
      $('typing')?.remove();
      let html;
      const apiRes = await callExternalFromSide(
        (text || '') +
        (attaches.length ? '\n\n[Файлы: ' + attaches.map(a => a.name).join(', ') + ']' : '') +
        (tabSnap.url ? '\n\n[Вкладка: ' + (tabSnap.title || '') + ' ' + tabSnap.url + ']' : '')
      );
      if (apiRes && apiRes.ok) {
        html = mdLite(apiRes.text);
        showToast('Ответ через ' + (bridgeApi && bridgeApi.provider), 'success');
      } else {
        if (apiRes && apiRes.error && apiRes.error !== 'not_configured') {
          html = '<span style="color:var(--danger)">Ошибка API: ' + escapeHtml(apiRes.error) +
            '</span><br><button type="button" class="retry-api" style="margin-top:8px;padding:6px 12px;border-radius:10px;border:1px solid var(--border);background:var(--surface);color:var(--text);cursor:pointer;font-weight:700;">Повторить</button>';
        } else {
          html = localReply(text, attaches, tabSnap);
        }
      }
      c.messages.push({ role: 'ai', text: html, html });
      c.updated = Date.now();
      await saveChats();
      renderChat();
      renderList();
      chatEl.querySelectorAll('.retry-api').forEach(btn => {
        btn.onclick = () => {
          input.value = text;
          autoResize();
          updateSend();
          send();
        };
      });
    }, 200);
  }

  async function toggleTheme() {
    const next = document.body.dataset.theme === 'dark' ? 'light' : 'dark';
    document.body.dataset.theme = next;
    const __ti = $('theme-icon'); if (__ti) __ti.textContent = next === 'dark' ? 'light_mode' : 'dark_mode';
    await storageSet({ [KEYS.theme]: next });
    showToast(next === 'dark' ? 'Тёмная тема' : 'Светлая тема', 'success');
  }

  function openPlusMenu() {
    const btn = $('btn-plus');
    if (!btn) return;
    const r = btn.getBoundingClientRect();
    plusMenu.classList.add('open');
    plusMenu.style.left = Math.min(r.left, window.innerWidth - 220) + 'px';
    plusMenu.style.bottom = (window.innerHeight - r.top + 8) + 'px';
    plusMenu.style.top = 'auto';
  }
  function closePlusMenu() {
    plusMenu.classList.remove('open');
  }

  // wire
  { const __el = $('btn-history'); if (__el) __el.onclick = openDrawer; }
  { const __el = $('drawer-close'); if (__el) __el.onclick = closeDrawer; }
  { const __el = $('drawer-overlay'); if (__el) __el.onclick = closeDrawer; }
  { const __el = $('btn-new'); if (__el) __el.onclick = () => newChat(true); }
  { const __el = $('drawer-new'); if (__el) __el.onclick = () => newChat(true); }
  /* btn-theme removed — theme in settings */
  { const __el = $('btn-send'); if (__el) __el.onclick = send; }
  { const __el = $('tab-chip'); if (__el) __el.onclick = analyzeTab; }
  {
    const __el = $('btn-plus');
    if (__el) __el.onclick = (e) => {
      e.stopPropagation();
      if (plusMenu.classList.contains('open')) closePlusMenu();
      else openPlusMenu();
    };
  }
  {
    const __el = $('btn-open-core');
    if (__el) __el.onclick = () => {
      try {
        chrome.runtime.sendMessage({ type: 'open-core-node' });
      } catch (e) {
        window.open('https://oracle-ai-pro.github.io/oracle/', '_blank');
      }
    };
  }

  plusMenu.querySelectorAll('button').forEach((btn) => {
    btn.onclick = () => {
      const act = btn.dataset.act;
      closePlusMenu();
      if (act === 'file') fileInput.click();
      if (act === 'tab') analyzeTab();
    };
  });
  fileInput.onchange = () => {
    addFiles(fileInput.files);
    fileInput.value = '';
  };

  input.addEventListener('input', () => { autoResize(); updateSend(); });
  input.addEventListener('focus', () => pulseComposer());
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  });

  ctx.querySelectorAll('button').forEach((btn) => {
    btn.onclick = () => {
      const id = state.ctxId;
      const act = btn.dataset.act;
      closeCtx();
      if (!id) return;
      if (act === 'rename') renameChat(id);
      if (act === 'delete') deleteChat(id);
    };
  });

  document.addEventListener('click', (e) => {
    if (!ctx.contains(e.target)) closeCtx();
    if (!plusMenu.contains(e.target) && !e.target.closest('#btn-plus')) closePlusMenu();
  });

  // refresh tab title when panel shown
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) refreshTabChip();
  });
  setInterval(refreshTabChip, 4000);


  (function wireSettings() {
    const btn = document.getElementById('btn-settings');
    const closeBtn = document.getElementById('settings-close');
    const overlay = document.getElementById('settings-overlay');
    if (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        openSettings(e);
      });
    }
    if (closeBtn) {
      closeBtn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        _settingsOpenedAt = 0; // allow close
        closeSettings(e);
      });
    }
    if (overlay) {
      overlay.addEventListener('click', function (e) {
        if (e.target !== overlay) return;
        _settingsOpenedAt = 0;
        closeSettings(e);
      });
    }
  })();
  document.querySelectorAll('[data-theme-set]').forEach(b => {
    b.addEventListener('click', async () => {
      const t = b.dataset.themeSet;
      document.body.dataset.theme = t;
      const icon = $('theme-icon');
      if (icon) icon.textContent = t === 'dark' ? 'light_mode' : 'dark_mode';
      await storageSet({ [KEYS.theme]: t });
      syncSettingsUI();
      showToast(t === 'dark' ? 'Тёмная тема' : 'Светлая тема', 'success');
    });
  });
  document.querySelectorAll('.accent-dot').forEach(d => {
    d.addEventListener('click', () => applyAccent(d.dataset.accent, true));
  });
  document.querySelectorAll('#set-providers [data-provider]').forEach(b => {
    b.addEventListener('click', () => {
      document.querySelectorAll('#set-providers [data-provider]').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
    });
  });
  $('set-key-vis')?.addEventListener('click', () => {
    const inp = $('set-api-key');
    if (!inp) return;
    inp.type = inp.type === 'password' ? 'text' : 'password';
  });
  $('set-api-save')?.addEventListener('click', saveSideApiFromForm);
  $('set-open-core2')?.addEventListener('click', () => {
    try { chrome.runtime.sendMessage({ type: 'open-core-node' }); }
    catch (e) { window.open('https://oracle-ai-pro.github.io/oracle/', '_blank'); }
  });
  $('set-pull-bridge')?.addEventListener('click', () => {
    refreshBridge();
    setTimeout(() => {
      syncSettingsUI();
      if (bridgeApi && bridgeApi.key) showToast('Ключ подтянут из Core Node', 'success');
      else showToast('Ключ в мосте не найден — откройте CN с API', 'error');
    }, 400);
  });


  /* ===== Context menu: Ask Core Node ===== */
  function applyPendingAsk(payload) {
    if (!payload || !payload.query) return;
    try {
      input.value = payload.query;
      autoResize();
      updateSend();
      pulseComposer();
      if (payload.kind === 'image') {
        const name = payload.imageName || 'image';
        const item = {
          id: uid(),
          name: name,
          size: 0,
          type: 'image/*',
          dataUrl: payload.dataUrl || null,
          isImage: true,
          remoteUrl: payload.imageUrl || null
        };
        // if no dataUrl but remote url, still show chip as file-ish image ref
        if (!item.dataUrl && payload.imageUrl) {
          item.isImage = true;
          item.dataUrl = payload.imageUrl; // may work for display
        }
        state.pending = state.pending.filter(p => p.name !== name);
        state.pending.push(item);
        renderAttach();
      }
      if (payload.pageUrl) {
        state.tabInfo = {
          title: payload.pageTitle || state.tabInfo.title || '',
          url: payload.pageUrl
        };
        const text = document.getElementById('tab-chip-text');
        if (text) text.textContent = payload.pageTitle || payload.pageUrl;
      }
      showToast('Ask Core Node: готово к отправке', 'success');
      input.focus();
    } catch (e) {
      console.warn('applyPendingAsk', e);
    }
  }

  function consumePendingAsk() {
    try {
      chrome.runtime.sendMessage({ type: 'side-consume-pending-ask' }, (res) => {
        if (chrome.runtime.lastError) return;
        if (res && res.payload) applyPendingAsk(res.payload);
      });
    } catch (e) {}
  }

  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === 'side-pending-ask' && msg.payload) {
        applyPendingAsk(msg.payload);
      }
    });
  } catch (e) {}


  loadAll();
  consumePendingAsk();
  setTimeout(consumePendingAsk, 500);
  setTimeout(consumePendingAsk, 1500);
  loadSideApiLocal();
  refreshBridge();
  setInterval(refreshBridge, 3000);


  /* ===== Sleep Mode ===== */
  const SLEEP_KEY = 'side_sleep_v1';
  let sleepTimer = null;
  let sleepMoveTimer = null;
  let sleepActive = false;
  let sleepCfg = { enabled: false, minutes: 3 };

  async function loadSleepCfg() {
    try {
      const r = await storageGet([SLEEP_KEY]);
      if (r[SLEEP_KEY]) {
        const c = typeof r[SLEEP_KEY] === 'string' ? JSON.parse(r[SLEEP_KEY]) : r[SLEEP_KEY];
        sleepCfg = { enabled: !!c.enabled, minutes: Number(c.minutes) || 3 };
      }
    } catch (e) {}
    syncSleepSettingsUI();
    resetSleepTimer();
  }

  function saveSleepCfg() {
    storageSet({ [SLEEP_KEY]: sleepCfg });
  }

  function syncSleepSettingsUI() {
    const en = document.getElementById('set-sleep-enabled');
    if (en) en.checked = !!sleepCfg.enabled;
    document.querySelectorAll('[data-sleep-min]').forEach(b => {
      b.classList.toggle('active', Number(b.dataset.sleepMin) === Number(sleepCfg.minutes));
    });
  }

  function resetSleepTimer() {
    if (sleepTimer) { clearTimeout(sleepTimer); sleepTimer = null; }
    if (!sleepCfg.enabled || sleepActive) return;
    const ms = Math.max(0.5, Number(sleepCfg.minutes) || 3) * 60 * 1000;
    sleepTimer = setTimeout(() => enterSleepMode(), ms);
  }

  function moveSleepModal() {
    const modal = document.getElementById('sleep-modal');
    const ov = document.getElementById('sleep-overlay');
    if (!modal || !ov) return;
    const pad = 16;
    const mw = modal.offsetWidth || 240;
    const mh = modal.offsetHeight || 120;
    const maxX = Math.max(pad, window.innerWidth - mw - pad);
    const maxY = Math.max(pad, window.innerHeight - mh - pad);
    const x = pad + Math.random() * (maxX - pad);
    const y = pad + Math.random() * (maxY - pad);
    modal.style.left = x + 'px';
    modal.style.top = y + 'px';
  }

  function enterSleepMode(fromPreview) {
    if (sleepActive && !fromPreview) return;
    sleepActive = true;
    if (sleepTimer) { clearTimeout(sleepTimer); sleepTimer = null; }
    document.body.classList.add('sleep-active');
    const ov = document.getElementById('sleep-overlay');
    if (ov) {
      ov.hidden = false;
      ov.setAttribute('aria-hidden', 'false');
    }
    // initial position
    requestAnimationFrame(() => {
      moveSleepModal();
      if (sleepMoveTimer) clearInterval(sleepMoveTimer);
      sleepMoveTimer = setInterval(moveSleepModal, 30000);
    });
  }

  function exitSleepMode() {
    if (!sleepActive) return;
    sleepActive = false;
    document.body.classList.remove('sleep-active');
    const ov = document.getElementById('sleep-overlay');
    if (ov) {
      ov.hidden = true;
      ov.setAttribute('aria-hidden', 'true');
    }
    if (sleepMoveTimer) { clearInterval(sleepMoveTimer); sleepMoveTimer = null; }
    resetSleepTimer();
  }

  function wireSleepMode() {
    const activity = () => {
      if (sleepActive) return;
      resetSleepTimer();
    };
    ['pointerdown', 'keydown', 'input', 'scroll', 'touchstart'].forEach(ev => {
      document.addEventListener(ev, activity, { passive: true });
    });
    document.getElementById('sleep-overlay')?.addEventListener('click', (e) => {
      e.preventDefault();
      exitSleepMode();
      if (typeof showToast === 'function') showToast('С возвращением', 'success');
    });

    document.getElementById('set-sleep-enabled')?.addEventListener('change', (e) => {
      sleepCfg.enabled = !!e.target.checked;
      saveSleepCfg();
      if (!sleepCfg.enabled) {
        exitSleepMode();
        if (sleepTimer) { clearTimeout(sleepTimer); sleepTimer = null; }
      } else {
        resetSleepTimer();
      }
      if (typeof showToast === 'function') {
        showToast(sleepCfg.enabled ? 'Sleep Mode включён' : 'Sleep Mode выключен', 'info');
      }
    });

    document.querySelectorAll('[data-sleep-min]').forEach(b => {
      b.addEventListener('click', () => {
        sleepCfg.minutes = Number(b.dataset.sleepMin) || 3;
        document.querySelectorAll('[data-sleep-min]').forEach(x => x.classList.toggle('active', x === b));
        saveSleepCfg();
        resetSleepTimer();
        if (typeof showToast === 'function') showToast('Таймаут: ' + sleepCfg.minutes + ' мин', 'info');
      });
    });

    document.getElementById('set-sleep-preview')?.addEventListener('click', () => {
      document.getElementById('settings-drawer')?.classList.remove('open');
      document.getElementById('settings-overlay')?.classList.remove('open');
      enterSleepMode(true);
    });

    loadSleepCfg();
  }

  // boot sleep after DOM wires
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wireSleepMode);
  } else {
    setTimeout(wireSleepMode, 0);
  }

})();