/* Side Core Node — SW + bridge + context menus */
const SIDE_PATH = 'sidepanel.html';
const BRIDGE_KEY = 'cn_bridge_v1';
const PENDING_ASK = 'side_pending_ask_v1';

chrome.runtime.onInstalled.addListener(async () => {
  try { await chrome.sidePanel.setOptions({ path: SIDE_PATH, enabled: true }); } catch (e) {}
  try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); } catch (e) {}
  setupContextMenus();
});

chrome.runtime.onStartup.addListener(async () => {
  try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); } catch (e) {}
  setupContextMenus();
});

(async () => {
  try {
    await chrome.sidePanel.setOptions({ path: SIDE_PATH, enabled: true });
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (e) {}
  setupContextMenus();
})();

function setupContextMenus() {
  try {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({
        id: 'ask-core-selection',
        title: 'Ask Core Node: «%s»',
        contexts: ['selection']
      });
      chrome.contextMenus.create({
        id: 'ask-core-image',
        title: 'Ask Core Node про картинку',
        contexts: ['image']
      });
      chrome.contextMenus.create({
        id: 'ask-core-page',
        title: 'Ask Core Node про страницу',
        contexts: ['page']
      });
    });
  } catch (e) {
    console.warn('contextMenus', e);
  }
}

async function openSidePanelForTab(tab) {
  try {
    const windowId = tab?.windowId;
    if (windowId != null) {
      await chrome.sidePanel.open({ windowId });
      return;
    }
  } catch (e) {}
  try {
    const win = await chrome.windows.getCurrent();
    if (win?.id != null) await chrome.sidePanel.open({ windowId: win.id });
  } catch (e) {
    console.warn('open side', e);
  }
}

async function queueAsk(payload) {
  await chrome.storage.local.set({ [PENDING_ASK]: { ...payload, ts: Date.now() } });
  // notify sidepanel if open
  try {
    chrome.runtime.sendMessage({ type: 'side-pending-ask', payload });
  } catch (e) {}
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'ask-core-selection') {
    const text = (info.selectionText || '').trim();
    if (!text) return;
    const q = 'Что значит «' + text.slice(0, 500) + '»?';
    await queueAsk({ kind: 'selection', query: q, selection: text, pageUrl: info.pageUrl || tab?.url || '' });
    await openSidePanelForTab(tab);
    return;
  }
  if (info.menuItemId === 'ask-core-image') {
    const src = info.srcUrl || '';
    const name = (src.split('/').pop() || 'image').split('?')[0] || 'image';
    const q = 'Что это на изображении «' + name + '»?';
    let dataUrl = null;
    // try fetch as data URL for preview
    try {
      if (src && (src.startsWith('http://') || src.startsWith('https://') || src.startsWith('data:'))) {
        if (src.startsWith('data:')) {
          dataUrl = src;
        } else {
          const res = await fetch(src);
          const blob = await res.blob();
          if (blob.size < 8 * 1024 * 1024) {
            dataUrl = await new Promise((resolve, reject) => {
              const r = new FileReader();
              r.onload = () => resolve(r.result);
              r.onerror = reject;
              r.readAsDataURL(blob);
            });
          }
        }
      }
    } catch (e) {
      console.warn('img fetch', e);
    }
    await queueAsk({
      kind: 'image',
      query: q,
      imageUrl: src,
      imageName: name,
      dataUrl,
      pageUrl: info.pageUrl || tab?.url || ''
    });
    await openSidePanelForTab(tab);
    return;
  }
  if (info.menuItemId === 'ask-core-page') {
    const title = tab?.title || 'страница';
    const url = tab?.url || info.pageUrl || '';
    const q = 'Кратко: о чём страница «' + title + '»?' + (url ? ' (' + url + ')' : '');
    await queueAsk({ kind: 'page', query: q, pageTitle: title, pageUrl: url });
    await openSidePanelForTab(tab);
  }
});

async function openSidePanel() {
  try {
    const win = await chrome.windows.getCurrent({ populate: false });
    if (win?.id != null) {
      await chrome.sidePanel.open({ windowId: win.id });
      return;
    }
  } catch (e) {}
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.windowId != null) await chrome.sidePanel.open({ windowId: tab.windowId });
  } catch (e) {
    console.warn('open side panel failed', e);
  }
}

chrome.commands.onCommand.addListener((cmd) => {
  if (cmd === 'toggle-side-core') openSidePanel();
});
chrome.action.onClicked.addListener(() => openSidePanel());

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'cn-bridge-sync') {
    const payload = msg.payload || {};
    chrome.storage.local.set({
      [BRIDGE_KEY]: payload,
      cn_bridge_ts: Date.now(),
      cn_bridge_reason: msg.reason || ''
    }, () => sendResponse({ ok: true }));
    return true;
  }

  if (msg?.type === 'cn-bridge-get') {
    chrome.storage.local.get([BRIDGE_KEY, 'cn_bridge_ts'], (r) => {
      sendResponse({ ok: true, payload: r[BRIDGE_KEY] || null, ts: r.cn_bridge_ts || 0 });
    });
    return true;
  }

  if (msg?.type === 'cn-bridge-push-to-tabs') {
    chrome.tabs.query({}, (tabs) => {
      const targets = (tabs || []).filter(t =>
        t.url && (
          t.url.includes('oracle-ai-pro.github.io') ||
          t.url.startsWith('http://localhost') ||
          t.url.startsWith('http://127.0.0.1') ||
          t.url.startsWith('file:')
        )
      );
      let n = 0;
      targets.forEach(t => {
        chrome.tabs.sendMessage(t.id, { type: 'cn-bridge-apply', payload: msg.payload }, () => {
          void chrome.runtime.lastError;
        });
        n++;
      });
      sendResponse({ ok: true, tabs: n });
    });
    return true;
  }

  if (msg?.type === 'open-core-node') {
    chrome.tabs.create({ url: msg.url || 'https://oracle-ai-pro.github.io/oracle/' });
    sendResponse({ ok: true });
    return true;
  }

  if (msg?.type === 'open-side-panel') {
    openSidePanel().then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg?.type === 'side-consume-pending-ask') {
    chrome.storage.local.get([PENDING_ASK], (r) => {
      const p = r[PENDING_ASK] || null;
      if (p) chrome.storage.local.remove(PENDING_ASK);
      sendResponse({ ok: true, payload: p });
    });
    return true;
  }
});
