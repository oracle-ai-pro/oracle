/* Bridge: Core Node page ↔ Side Core Node extension */
(function () {
  const KEYS = [
    'oracle_custom_api',
    'oracle_chat_sessions',
    'oracle_current_session',
    'oracle_project_tree_v2',
    'oracle_story_books'
  ];

  function snapshot() {
    const payload = {};
    KEYS.forEach((k) => {
      try { payload[k] = localStorage.getItem(k); } catch (e) { payload[k] = null; }
    });
    payload._href = location.href;
    payload._ts = Date.now();
    return payload;
  }

  function push(reason) {
    try {
      chrome.runtime.sendMessage({ type: 'cn-bridge-sync', reason: reason || 'poll', payload: snapshot() });
    } catch (e) {}
  }

  // initial + interval
  push('boot');
  setInterval(() => push('interval'), 2500);

  window.addEventListener('storage', (e) => {
    if (!e.key || KEYS.includes(e.key)) push('storage:' + (e.key || '*'));
  });

  // Core Node can dispatch after API save
  window.addEventListener('oracle-bridge-sync', () => push('event'));

  // Apply chats/API written from extension when page is open
  chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg?.type === 'cn-bridge-apply') {
      try {
        const p = msg.payload || {};
        Object.keys(p).forEach((k) => {
          if (p[k] == null) return;
          if (KEYS.includes(k) || k.startsWith('oracle_')) {
            localStorage.setItem(k, typeof p[k] === 'string' ? p[k] : JSON.stringify(p[k]));
          }
        });
        window.dispatchEvent(new CustomEvent('oracle-bridge-applied', { detail: p }));
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
      return true;
    }
    if (msg?.type === 'cn-bridge-ping') {
      sendResponse({ ok: true, href: location.href });
      return true;
    }
  });
})();
