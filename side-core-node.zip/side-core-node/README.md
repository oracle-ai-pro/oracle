# Side Core Node 0.2 — bridge

## Связка с Core Node
1. Установите расширение (распакованное).
2. Откройте **Core Node** на `oracle-ai-pro.github.io` (или localhost / full.html).
3. В CN: **Настройки → Сторонние API** — включите, выберите Gemini/и др., сохраните ключ.
4. Content script копирует `oracle_custom_api` (+ чаты) в `chrome.storage`.
5. Side panel подхватывает ключ и шлёт запросы в API.

## Хоткей
Alt+Shift+C (или иконка).

## Файлы
- `content.js` — мост со страницы CN
- `background.js` — storage + side panel
- `sidepanel.*` — UI

## Ask Core Node (ПКМ)
- Выделение текста → **Ask Core Node: «…»**
- Картинка → **Ask Core Node про картинку**
- Страница → **Ask Core Node про страницу**

Открывает side panel и подставляет вопрос (для картинки — вложение).
